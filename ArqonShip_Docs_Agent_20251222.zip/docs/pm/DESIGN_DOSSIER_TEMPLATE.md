---
schema_version: "0.1"
dossier_id: "DOS-[YYYYMMDD]-[product-slug]"
product_id: "[product-slug]"
owner: "nexus"
status: "draft"
created_at: "[YYYY-MM-DD]"
hypothesis:
  problem: "[One sentence problem statement]"
  claim: "[One sentence hypothesis]"
  falsification: "[What evidence would prove this wrong?]"
mvp_boundary:
  in_scope:
    - "[Critical feature 1]"
    - "[Critical feature 2]"
  non_goals:
    - "[Out of scope item]"
acceptance_proofs:
  - "[Proof 1: e.g. CLI command returns 0]"
  - "[Proof 2: e.g. Artifact X exists]"
evidence:
  links: []
constitution_refs:
  - "constitution.md"
  - "docs/pm/00_VISION_STRATEGY.md"
---

# Design Dossier: [Product Name]

## 1. Context & Problem
[Why are we doing this? Link to strategy]

## 2. Hypothesis
[If we build X, then Y will happen. We know we are wrong if Z.]

## 3. MVP Definition
[Strict boundary of what is IN and OUT]

## 4. Evidence Plan
[How will we prove it works? Specific artifacts]
